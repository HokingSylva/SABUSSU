import pyaudio
import numpy as np
import time
import wave
import tkinter as tk
from tkinter import messagebox as msg
import random
import threading as thd

CHUNK = 1024
RATE = 44100
Switch = 0
Sample = 0

def Bgm_Player():

    Key_Value = random.randrange(0,4)
    Sound_Group = {0:'sound\\거기 누구 없소.wav',
               1: 'sound\\무슨 말이라도 해주세요.wav',
               2: 'sound\\아니 주인님 왜 방송중인데 아무 소리도 나지 않는거죠.wav',
               3: 'sound\\혹시 마이크를 끄고 계신건가요.wav'}


    with wave.open(Sound_Group[Key_Value], 'rb') as f:
        p = pyaudio.PyAudio()
        stream = p.open(format = p.get_format_from_width(f.getsampwidth()),
                        channels = f.getnchannels(),
                        rate = f.getframerate(),
                        output = True)
        data = f.readframes(CHUNK)
        while data:
            stream.write(data)
            data= f.readframes(CHUNK)

        stream.write(data)
        stream.close()

        p.terminate()

def switch():

    global Switch

    if Switch ==1:
        Switch = 0

    elif Switch == 0:
        Switch=1

def RealtimeRecording():

    global Switch

    Switch = 0


    
    RSL= []

    finish = 0

    p=pyaudio.PyAudio()
    stream=p.open(format=pyaudio.paInt16,
                  channels=1,
                  rate=RATE,
                  input=True,
                  frames_per_buffer=CHUNK,
                  input_device_index=1)
    s= Sample
    TIC = 0
    
    while Switch == 0:

        data = np.frombuffer(stream.read(CHUNK),dtype=np.int16)

        time.sleep(0.1)

        RSL.append(int(np.average(np.abs(data))))

        Realtime_Sound_Level = max(RSL)
        
        print(Realtime_Sound_Level)

        r= Realtime_Sound_Level

        if s >= r:
            TIC = TIC+0.1
        
        elif s < r:
            TIC = 0

        if TIC >= C:
            Bgm_Player()
            TIC = 0
      
        print(TIC)
        RSL = []

 
    stream.stop_stream()
    stream.close()
    p.terminate()

def Sample_Recording():

    global Sample

    t_end = time.time() + 6

    SSL = []

    audio = pyaudio.PyAudio()

    stream = audio.open(format = pyaudio.paInt16,
                        channels = 1,
                        rate = 44100,
                        input= True,
                        input_device_index=1,
                        frames_per_buffer=1024)

    frames = []

    while (time.time() <= t_end):
         
       data = np.frombuffer(stream.read(CHUNK),dtype=np.int16)
       frames.append(data)
       SSL.append(int(np.average(np.abs(data))))
    
    Sample = max(SSL)
    print(Sample)


    stream.stop_stream()
    stream.close()
    audio.terminate()


    

def Option_Menu():

    Opt=tk.Tk()
    Opt.title('옵션')
    Opt.geometry('300x200+740+300')
    Opt.configure(bg = 'white')

    Option1 = tk.Button(Opt,
                        text = '주변 소음 측정하기',
                        width = 300,
                        command = Noise_Measure)
    
    Option2 = tk.Button(Opt,
                        text = '타이머 설정',
                        width = 300,
                        command = Timer_Option)
    
    Option1.pack(side = 'top')
    Option2.pack(side = 'top')

    Opt.mainloop()

def Timer_Option():
 
    TO = tk.Tk()
    TO.title('타이머 설정하기')
    TO.geometry('300x100+740+300')
    TO.configure(bg = 'white')

    Explain = tk.Label(TO,
                       text = '타이머는 5초부터 5분까지 설정이 가능합니다.')
    Explain.pack(side = 'top')

    
    textbox = tk.Entry(TO,
                        width = 300,
                       background = 'cyan')
    textbox.insert(0,'5')
    textbox.pack(side = 'top')

    

    def Message():

        global C

        C = int(textbox.get())

        print(C)
       
        if C> 300 :

            print(C)
            
            Error = msg.showerror('에러','타이머는 5초부터 5분까지 설정이 가능합니다')

        elif C< 5 :

            print(C)
            
            Error = msg.showerror('에러','타이머는 5초부터 5분까지 설정이 가능합니다')

        else:
            TO.destroy()

    



    confirm = tk.Button(TO,
                         text = '확인',
                         command = Message)

    confirm.pack(side = 'bottom')

def Noise_Measure():

    Ti = time.time() + 5

    NM = tk.Tk()
    NM.title('주변 소음 측정하기')
    NM.geometry('300x200+740+400')
    NM.configure(bg = 'white')

    ML1 = tk.Label(NM, text = '측정버튼을 누르고 키보드와 마우스를 눌러주세요.')
    ML2 = tk.Label(NM, text = ' 측정이 끝난 후 창이 자동으로 닫힙니다.')

    def M():

        ML1.configure(text = '측정중입니다. 마우스와 키보드를 눌러주세요.')


    MS = tk.Button(NM,
                   text = '측정시작하기',
                   width = 30,
                   height = 5,
                   bg = 'cyan',
                   command = lambda:[M(),Sample_Recording(),NM.destroy()]
                   )
    MS.place(x = 40, y = 20)


    ML2.pack(side = 'bottom')
    ML1.pack(side = 'bottom')
    NM.mainloop()


    if time.time() == Ti:
        NM.destroy()


def th():

    th = thd.Thread(target = RealtimeRecording)
    th.daemon = True
    th.start()

def COMPARING():

    SP=tk.Tk()
    SP.title('사운드체크중')
    SP.configure(bg = 'white')

    
  

    WPI = tk.PhotoImage(file = 'img\\wp.png', master = SP)
    Back = tk.Label(SP, image = WPI, border = '0')
    
    Label = tk.Label(SP,
                     text = '사운드체크를 시작하려면 시작을 눌러주세요.',
                     font = ('바탕',30),
                     background = 'white',
                     border = '0'
                     )
    def Exp():
        Label.configure(text = '사운드를 체크중입니다. 쉬지 않고 말해주세요')

    def EExp():
        Label.configure(text = '사운드체크를 시작하려면 시작을 눌러주세요.')

    STOP = tk.Button(SP,
                     text = '정지', 
                     width = 50,
                     command = lambda:[switch(), EExp()],
                     background = 'white',
                     border = '1')
    START = tk.Button(SP,
                      text = '시작',
                      width = 50,
                      command =lambda:[Exp(), th()],
                      background='white',
                      border = '1')
    Back.pack()
    Label.pack()
    START.pack()
    STOP.pack()

    SP.mainloop()
   
def Main():

    base =tk.Tk()
    base.title('사운드가 비면 쓰나!')
    base.geometry('1600x900+740+400')

    Start_Img = tk.PhotoImage(file = 'img\\st.png')
    Option_Img = tk.PhotoImage(file = 'img\\option.png')
    WallPaper_Img = tk.PhotoImage(file = 'img\\WallPaper.png')

    WallPaperLabel = tk.Label(image = WallPaper_Img,
                              width = 1646, height = 991,
                              background = 'white')

    WallPaperLabel.place(x=0,y=0)

    Start_btn1 = tk.Button(base,
                           image = Start_Img,
                           height = 200,
                           width = 200,
                           command = COMPARING,
                           border = '0',
                           background = 'white')

    Start_btn1.place(x=200, y= 0)
    Option_btn = tk.Button(base,
                           image = Option_Img,
                           height = 200,
                           width = 200,
                           command = Option_Menu,
                           border = '0',
                           background = 'white')

    Option_btn.place(x=1000, y=0)

    base.mainloop()

Main()
